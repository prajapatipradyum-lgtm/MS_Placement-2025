function Ke = elementStiffness(coords, E, nu, t)
% Compute element stiffness matrix for linear triangular plane stress element
%
% Inputs:
%   coords - 3x2 matrix of node coordinates [x y]
%   E      - Young's modulus
%   nu     - Poisson's ratio
%   t      - element thickness
%
% Output:
%   Ke     - 6x6 element stiffness matrix

x = coords(:,1);
y = coords(:,2);

A = polyarea(x,y);

B = zeros(3,6);
b = [y(2)-y(3); y(3)-y(1); y(1)-y(2)];
c = [x(3)-x(2); x(1)-x(3); x(2)-x(1)];

B(1,1:2:5) = b';
B(2,2:2:6) = c';
B(3,1:2:5) = c';
B(3,2:2:6) = b';
B = B / (2*A);

D = (E/(1 - nu^2)) * [1 nu 0; nu 1 0; 0 0 (1 - nu)/2];

Ke = t * A * (B' * D * B);
end
