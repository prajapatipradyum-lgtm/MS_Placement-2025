function [Kmod, Fmod, freeDofs] = applyBoundaryConditions(K, F, nodes, tol)
% Fix displacement on left edge (x=0)
%
% Inputs:
%   K, F   - global stiffness matrix and load vector
%   nodes  - nodal coordinates
%   tol    - tolerance for node selection on left edge
%
% Outputs:
%   Kmod, Fmod - modified system
%   freeDofs   - DOFs not fixed

fixedNodes = find(abs(nodes(:,1)) < tol);
fixedDofs = [2*fixedNodes-1; 2*fixedNodes];  % all dofs (u,v) fixed

allDofs = 1:length(F);
freeDofs = setdiff(allDofs, fixedDofs);

Kmod = K(freeDofs, freeDofs);
Fmod = F(freeDofs);

end
