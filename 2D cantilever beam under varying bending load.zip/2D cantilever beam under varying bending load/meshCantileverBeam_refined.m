function [nodes, elems] = meshCantileverBeam_refined(L, h, nx, ny)
% Generate refined triangular mesh for better bending accuracy
[xv, yv] = meshgrid(linspace(0,L,nx+1), linspace(0,h,ny+1));
nodes = [xv(:), yv(:)];

DT = delaunayTriangulation(nodes);
elems = DT.ConnectivityList;
end
