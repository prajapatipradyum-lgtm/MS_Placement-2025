% 2D Cantilever with Linearly Varying Load
clear; clc; close all;

% Parameters
L = 1.0;        % Length (m)
h = 0.1;        % Height (m) 
t = 0.05;       % Thickness (m)
E = 210e9;      % Young's modulus (Pa)
nu = 0.3;       % Poisson's ratio
w0 = 1000;      % Max distributed load (N/m)
nx = 80;        % Elements along length
ny = 16;        % Elements along height

% Generate refined mesh
[nodes, elems] = meshCantileverBeam_refined(L, h, nx, ny);

% Assemble system with distributed load
[K, F] = assembleGlobalSystem_distributed(nodes, elems, E, nu, t, w0, L);

% Apply boundary conditions (fix left edge)
tol = 1e-6;
[Kmod, Fmod, freeDofs] = applyBoundaryConditions(K, F, nodes, tol);

% Solve for displacements
U = zeros(2*size(nodes,1), 1);
U(freeDofs) = Kmod \ Fmod;

% Find tip deflection
maxX = max(nodes(:,1));
endNodes = find(abs(nodes(:,1) - maxX) < tol);
midY = h/2;
[~, idx] = min(abs(nodes(endNodes, 2) - midY));
tipNode = endNodes(idx);
tipDispNumerical = U(2*tipNode);

% Analytical solution for linearly varying load
I = t * h^3 / 12;  % Second moment of area
tipDispAnalytical = w0 * L^4 / (30 * E * I);  % Correct formula

% Results
fprintf('\n=== RESULTS ===\n');
fprintf('Numerical tip deflection: %e m\n', abs(tipDispNumerical));
fprintf('Analytical tip deflection: %e m\n', tipDispAnalytical);
fprintf('Percent error: %.2f%%\n', 100*abs(tipDispAnalytical - abs(tipDispNumerical))/tipDispAnalytical);

% Compute and visualize stresses
sigma = computeElementStresses(nodes, elems, U, E, nu);
visualizeResults_distributed(nodes, elems, U, sigma, w0, L);
