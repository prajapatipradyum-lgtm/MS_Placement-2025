function sigma = computeElementStresses(nodes, elems, U, E, nu)
% Compute element stresses (\sigma_xx, \sigma_yy, \tau_xy)
%
% Inputs:
%   nodes - N×2 nodal coordinates
%   elems - M×3 element connectivity
%   U     - 2*N global displacement vector [u1;v1;u2;v2;...]
%   E, nu - material properties
%
% Output:
%   sigma - M×3 matrix containing [sigma_xx sigma_yy tau_xy] per element

D = (E/(1-nu^2)) * [1 nu 0; nu 1 0; 0 0 (1-nu)/2];
sigma = zeros(size(elems,1),3);

for el = 1:size(elems,1)
    idx = elems(el,:);
    coords = nodes(idx,:);
    
    x = coords(:,1);
    y = coords(:,2);
    A = polyarea(x,y);
    
    b = [y(2)-y(3); y(3)-y(1); y(1)-y(2)];
    c = [x(3)-x(2); x(1)-x(3); x(2)-x(1)];
    
    B = zeros(3,6);
    B(1,1:2:5) = b';
    B(2,2:2:6) = c';
    B(3,1:2:5) = c';
    B(3,2:2:6) = b';
    B = B / (2*A);
    
    dofs = reshape([2*idx-1; 2*idx],[],1);
    sigma(el,:) = (D * B * U(dofs))';
end
end
