function visualizeResults(nodes, elems, U, sigma)
% Plot deformed shape and stress contours
%
% Inputs:
%   nodes - N×2 nodal coords
%   elems - M×3 connectivity
%   U     - 2N×1 nodal displacements
%   sigma - M×3 element stresses

scaleFactor = 1000; % Amplify displacements for visualization

deformedNodes = nodes + scaleFactor * [U(1:2:end), U(2:2:end)];

figure;
subplot(1,2,1);
triplot(elems, nodes(:,1), nodes(:,2), 'k');
axis equal tight;
title('Original Mesh');
xlabel('x (m)'); ylabel('y (m)');

subplot(1,2,2);
trimesh(elems, deformedNodes(:,1), deformedNodes(:,2), zeros(size(nodes,1),1), 'EdgeColor', 'k');
title(sprintf('Deformed Shape (scaled x%d)', scaleFactor));
axis equal tight;
xlabel('x (m)'); ylabel('y (m)');

% Stress contour
figure;
figure;
patch('Faces', elems, 'Vertices', nodes, ...
      'FaceVertexCData', accumarray(elems(:), repelem(sigma(:,1),3), [size(nodes,1), 1], @mean), ...
      'FaceColor', 'interp', 'EdgeColor', 'k');
title('\sigma_{xx} Stress Distribution');
xlabel('x (m)'); ylabel('y (m)');
axis equal tight; view(2); colorbar;

shading interp; colorbar;
title('\sigma_{xx} Stress Distribution');
xlabel('x (m)'); ylabel('y (m)');
view(2); axis equal tight;
end
