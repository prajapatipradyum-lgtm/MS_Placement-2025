function visualizeResults_distributed(nodes, elems, U, sigma, w0, L)
% Visualize results for distributed load case

scaleFactor = 1000;
deformedNodes = nodes + scaleFactor * [U(1:2:end), U(2:2:end)];

% Plot original and deformed mesh
figure;
subplot(1,2,1);
triplot(elems, nodes(:,1), nodes(:,2), 'k-');
axis equal tight;
title('Original Mesh');
xlabel('x (m)'); ylabel('y (m)');

% Show load distribution
hold on;
h = max(nodes(:,2));
x_load = linspace(0, L, 50);
w_load = w0 * (1 - x_load/L);
y_load = h + 0.01 + w_load/max(w_load) * 0.02;  % Scale for visualization
plot(x_load, y_load, 'r-', 'LineWidth', 2);
text(L/2, max(y_load)+0.01, 'w(x) = w_0(1-x/L)', 'HorizontalAlignment', 'center');

subplot(1,2,2);
trimesh(elems, deformedNodes(:,1), deformedNodes(:,2), zeros(size(nodes,1),1), 'EdgeColor', 'k');
title(sprintf('Deformed Shape (scaled ×%d)', scaleFactor));
axis equal tight;
xlabel('x (m)'); ylabel('y (m)');

% Stress contour
figure;
patch('Faces', elems, 'Vertices', nodes, ...
      'FaceVertexCData', accumarray(elems(:), repelem(sigma(:,1),3), [size(nodes,1), 1], @mean), ...
      'FaceColor', 'interp', 'EdgeColor', 'k');
title('\sigma_{xx} Stress Distribution');
xlabel('x (m)'); ylabel('y (m)');
axis equal tight; colorbar;
end
