function [K, F] = assembleGlobalSystem_distributed(nodes, elems, E, nu, t, w0, L)
% Assemble stiffness and apply linearly varying distributed load
%
% Inputs:
%   nodes, elems - mesh
%   E, nu, t     - material & thickness
%   w0           - max load intensity at x=0 (N/m)
%   L            - beam length (m)
%
% Outputs:
%   K, F         - global stiffness matrix and load vector

Nnodes = size(nodes,1);
K = sparse(2*Nnodes, 2*Nnodes);
F = zeros(2*Nnodes,1);

% 1) Assemble global stiffness
for el = 1:size(elems,1)
    idx = elems(el,:);
    coords = nodes(idx,:);
    Ke = elementStiffness(coords, E, nu, t);
    dofs = reshape([2*idx-1; 2*idx], [], 1);
    K(dofs,dofs) = K(dofs,dofs) + Ke;
end

% 2) Apply linearly varying load on top edge (y = max y)
ymax = max(nodes(:,2));
tol = 1e-8;
topNodes = find(abs(nodes(:,2) - ymax) < tol);

% Sort top nodes by x-coordinate
[~, order] = sort(nodes(topNodes,1));
topNodes = topNodes(order);

% Compute dx for each node
xcoords = nodes(topNodes,1);
dx = zeros(size(xcoords));
dx(1) = xcoords(2) - xcoords(1);
dx(end) = xcoords(end) - xcoords(end-1);
dx(2:end-1) = (xcoords(3:end) - xcoords(1:end-2))/2;

% Distribute nodal forces: F_y = -w(x_i) * dx_i
for i = 1:length(topNodes)
    nodeID = topNodes(i);
    x_i = xcoords(i);
    w_i = w0 * (1 - x_i / L);
    F(2*nodeID) = F(2*nodeID) - w_i * dx(i);
end

fprintf('Correct total applied load: %.2f N\n', -sum(F(2:2:end)));
end
